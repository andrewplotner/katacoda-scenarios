#!/bin/bash
sleep 15
echo "done" >> /root/katacoda-finished
sleep 15
echo "done" >> /root/katacoda-background-finished