To indicate action happening in the background, a progress spinner can help provide uses with helpful feedback.

This example is waiting for two background scripts to finish, each taking 15 seconds.