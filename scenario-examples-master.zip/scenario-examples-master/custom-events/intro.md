

Katacoda provides a service that listens to events defined in the scenario and allows to override the default behavior of the platform.
This scenario will show you how to use custom events.
