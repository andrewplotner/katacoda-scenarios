tar --exclude=dist/ --exclude=.git/ --exclude=.idea/ --exclude=build-zip.sh --exclude=.DS_Store --exclude=node_modules/ --exclude=css/ -zcvf site.tar.gz .
