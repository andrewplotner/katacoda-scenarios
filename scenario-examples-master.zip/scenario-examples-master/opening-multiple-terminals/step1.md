`echo "Run in T1"`{{execute T1}}

<pre>`echo "Run in T1"`{{execute T1}}</pre>


`echo "Run in T2"`{{execute T2}}

<pre>`echo "Run in T2"`{{execute T2}}</pre>


`echo "No Terminal Defined"`{{execute}}

<pre>`echo "No Terminal Defined"`{{execute}}</pre>