Example of embedding a video on the intro screen. 

<iframe style="width: 700px;height: 400px;" src="https://www.youtube-nocookie.com/embed/KeJJ34BvA7Q" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

Here is the HTML example:

<pre>
&lt;iframe style=&quot;width: 700px;height: 400px;&quot; src=&quot;https://www.youtube-nocookie.com/embed/KeJJ34BvA7Q&quot; frameborder=&quot;0&quot; allow=&quot;accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture&quot; allowfullscreen&gt;&lt;/iframe&gt;
</pre>

*Note:* On the Intro panel, the width and height must be set via the style attribute.
