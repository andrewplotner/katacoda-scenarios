Within the Assets directory, images can be embedded into the scenarios.

In this scenario, within the Assets directory, a `logo-text-with-head.png` file exists. Only images within the Assets directory are available.

<pre>
![Katacoda Logo](./assets/logo-text-with-head.png)
</pre>

![Katacoda Logo](./assets/logo-text-with-head.png)

While relative paths can work, for most browser support we recommend using the absolute path.
