To provide users with more information or context, a Answer section can be provided. 

Here is the snippet from Step 2 within the `index.json`.
<pre class="file">
"details": {
    "steps": [
        {
            "title": "Step 2 - Show Answers",
            "text": "step2.md",
            "answer": "step2-answer.md"
        }
    ]
}
</pre>