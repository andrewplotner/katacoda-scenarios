This allows you to display additional information to help the user with the scenario.

Such as, the correct command the user needs to run:

`git init`{{execute}}