<pre>[[HOST_IP]]</pre>

`[[HOST_IP]]`{{execute}}

<pre>[[HOST2_IP]]</pre>

`[[HOST2_IP]]`{{execute}}
