echo "The IP address for this environment is [[HOST_IP]]"
