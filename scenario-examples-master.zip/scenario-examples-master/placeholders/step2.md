Render port 8500: https://[[HOST_SUBDOMAIN]]-8500-[[KATACODA_HOST]].environments.katacoda.com/

Render port 8500: <pre>https://[[HOST_SUBDOMAIN]]-8500-[[KATACODA_HOST]].environments.katacoda.com/</pre>

Render port 80: <pre>https://[[HOST_SUBDOMAIN]]-80-[[KATACODA_HOST]].environments.katacoda.com/</pre>

Display page allowing user to select port:
<pre>https://[[HOST_SUBDOMAIN]]-[[KATACODA_HOST]].environments.katacoda.com/</pre>
 
