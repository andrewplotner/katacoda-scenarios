The purpose of the **Interactive Quiz** is to help retain knowledge discussed within the scenario and highlight the key topics you want users to remember. 

Within the quiz, users have complete access to the terminal environment. This allows them to explore the environment to identify the correct answer in order to proceed. 

Users need to answer all the questions correctly to get proceed to the next step.