# Development

## Available Make targets

List all available Make targets with information.

```bash
make help
```

## Development environment

Start docker container with development enviroment.

```bash
make bash
```

## Validate

Validate the code.

```bash
make validate
```
