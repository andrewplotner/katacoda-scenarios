In this scenario, you will learn how to create a course, a series of Katacoda scenarios collected together. 

The advantage of creating a course is the ability to group related scenarios to provide users with a clear explanation and order to complete the content.