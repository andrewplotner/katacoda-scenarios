Example using the VS Code / Terminal Split screen terminal layout
