The Katacoda `iframe` UI Layout provides a full webpage experience.

# Index.json

Example:

<pre>
"environment": {
    "uilayout": "iframe"
},
"backend": {
    "url": "https://httpbin.org"
}
</pre>

## Important

The URL must be HTTPS and not block being embedded via an iframe.
