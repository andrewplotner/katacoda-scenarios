The Katacoda `terminal-terminal` UI Layout provides a full Terminal experience. 

# Index.json

Example:

<pre>
"environment": {
    "uilayout": "terminal-terminal"
},
</pre>

# Helper Functionality

`echo "Running a command on Host 1"`{{execute HOST1}}

`echo "Running a command on Host 2"`{{execute HOST2}}

Other Terminal and Markdown functionality is available at https://katacoda.com/scenario-examples/scenarios/markdown-extensions