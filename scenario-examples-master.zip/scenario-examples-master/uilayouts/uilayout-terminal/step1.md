The Katacoda `terminal` UI Layout provides a full Terminal experience. 

# Index.json

Example:

<pre>
"environment": {
    "uilayout": "terminal"
},
</pre>

# Helper Functionality

`echo "Running a command"`{{execute}}

Other Terminal and Markdown functionality is available at https://katacoda.com/scenario-examples/scenarios/markdown-extensions