echo "This is automatically run when the scenario"

pwd
ls -lha