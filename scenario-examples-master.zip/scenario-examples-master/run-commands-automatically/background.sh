#!/bin/bash

touch /root/createdFromBackgroundScript