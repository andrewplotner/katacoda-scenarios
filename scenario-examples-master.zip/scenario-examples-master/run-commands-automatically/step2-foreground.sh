echo "This is automatically run when the step starts"
