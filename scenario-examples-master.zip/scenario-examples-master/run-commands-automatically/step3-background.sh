#!/bin/bash

echo "This is a background script with a long running process"

sleep 10

echo "done" >> /opt/.backgroundfinished