#!/bin/bash

touch /root/createdFromStep2BackgroundScript