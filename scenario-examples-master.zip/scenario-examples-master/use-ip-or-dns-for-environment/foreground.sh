echo "The IP address for this environment is [[HOST_IP]]"
echo "The URL to access Port 80 is [[HOST_SxeUBDOMAIN]]-80-[[KATACODA_HOST]].[[KATACODA_DOMAIN]]"
