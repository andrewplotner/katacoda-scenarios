## IP Address

`echo [[HOST_IP]]`{{execute}}

<pre>[[HOST_IP]]</pre>

## URL

`echo [[HOST_SUBDOMAIN]]-80-[[KATACODA_HOST]].[[KATACODA_DOMAIN]]`{{execute}}

<pre>[[HOST_SUBDOMAIN]]-80-[[KATACODA_HOST]].[[KATACODA_DOMAIN]]</pre>

<pre>[[HOST_SUBDOMAIN]]</pre>

<pre>[[KATACODA_HOST]]</pre>

<pre>[[KATACODA_DOMAIN]]</pre>
