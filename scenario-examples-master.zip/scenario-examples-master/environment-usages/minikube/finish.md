Start using the Minikube environment for your content by setting the `imageid` to `minikube`.

For example:

<pre class="file">
"environment": {
  "uilayout": "terminal"
},
"backend": {
  "imageid": "minikube"
}
</pre>