Start using the Multi-node Kubernetes environment for your content by setting the `imageid` to `kubernetes-cluster`.

For example:

<pre class="file">
"environment": {
  "uilayout": "terminal"
},
"backend": {
  "imageid": "kubernetes-cluster"
}
</pre>