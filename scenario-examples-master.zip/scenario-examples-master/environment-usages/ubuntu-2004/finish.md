Start using the Ubuntu environment for your content by setting the `imageid` to `ubuntu:2004`.

For example:

<pre class="file">
"backend": {
  "imageid": "ubuntu:2004"
}
</pre>
