The Katacoda Ubuntu Environment is a flexible single node environment. Users are connected to the environment as `root`. This provides them with full flexibility to install additional packages, explore the internals of Linux and experiment with new ideas.

The environment also comes with Docker, meaning additional containers can be pulled and access as and when required.

