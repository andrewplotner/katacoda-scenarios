Start using the Ubuntu environment for your content by setting the `imageid` to `ubuntu:1804`.

For example:

<pre class="file">
"backend": {
  "imageid": "ubuntu:1804"
}
</pre>

Looking for Ubuntu 20.04? Use the imageid `ubuntu:2004`