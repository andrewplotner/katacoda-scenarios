#!/bin/bash
cd /root/
touch hello-world