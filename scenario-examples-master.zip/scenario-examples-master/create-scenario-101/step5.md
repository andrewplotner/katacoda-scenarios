As changes are being made to the content, when they are pushed into the master branch of a Git repository, the content on Katacoda can automatically be updated via a webhook.

To configure the Webhook, follow the guide at [katacoda.com/docs/configure-git](https://katacoda.com/docs/configure-git).

Once the webhook is installed, everytime you make a push to update to your content, Katacoda will be automatically updated.