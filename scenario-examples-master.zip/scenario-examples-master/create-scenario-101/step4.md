For those who prefer an IDE based extension, Katacoda has extended Visual Studio Code for scenario management.

This can be installed from the [Katacoda page on the Visual Studio Marketplace](https://marketplace.visualstudio.com/items/Katacoda.vscode/).

After installation, you can create new scenarios, add steps and have quick access to the Katacoda markdown features via snippets.